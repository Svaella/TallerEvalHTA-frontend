import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class InputForm extends StatelessWidget {
  final Map<String, dynamic> formData;
  final Function(String, dynamic) onChanged;

  const InputForm({
    Key? key,
    required this.formData,
    required this.onChanged,
  }) : super(key: key);

  Widget _buildTextField(
    String label,
    String keyName,
    TextInputType inputType, {
    String? Function(String?)? validator,
    List<TextInputFormatter>? inputFormatters,
  }) {
    return TextFormField(
      decoration: InputDecoration(labelText: label),
      initialValue: formData[keyName]?.toString(),
      keyboardType: inputType,
      inputFormatters: inputFormatters,
      validator: validator,
      onChanged: (value) => onChanged(keyName, value),
    );
  }

  Widget _buildDropdown(String label, String keyName, List<String> opciones) {
    return DropdownButtonFormField<String>(
      decoration: InputDecoration(labelText: label),
      value: formData[keyName],
      items: opciones.map((op) => DropdownMenuItem(value: op, child: Text(op))).toList(),
      dropdownColor: Colors.grey[900],
      onChanged: (value) => onChanged(keyName, value),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 24),
        _buildDropdown("Sexo", "Sexo", ["Hombre", "Mujer"]),
        const SizedBox(height: 24),

        // Edad: 18–100, máx 3 dígitos
        _buildTextField(
          "Edad", "Edad", TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(3)],
          validator: (value) {
            if (value == null || value.isEmpty) return 'Campo obligatorio';
            final edad = int.tryParse(value);
            if (edad == null || edad < 18 || edad > 100) return 'Debe estar entre 18 y 100 años';
            return null;
          },
        ),
        const SizedBox(height: 24),

        // Peso: 20–180, máx 3 dígitos enteros + 1 decimal
        _buildTextField(
          "Peso (kg)", "Peso", TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'^\d{0,3}(\.\d{0,1})?')),
          ],
          validator: (value) {
            if (value == null || value.isEmpty) return 'Campo obligatorio';
            final peso = double.tryParse(value);
            if (peso == null || peso < 20 || peso > 180) return 'Debe estar entre 20 y 180 kg';
            return null;
          },
        ),
        const SizedBox(height: 24),

        // Altura: 100–220, máx 3 dígitos enteros + 1 decimal
        _buildTextField(
          "Altura (cm)", "Altura", TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'^\d{0,3}(\.\d{0,1})?')),
          ],
          validator: (value) {
            if (value == null || value.isEmpty) return 'Campo obligatorio';
            final altura = double.tryParse(value);
            if (altura == null || altura < 100 || altura > 220) return 'Debe estar entre 100 y 220 cm';
            return null;
          },
        ),
        const SizedBox(height: 24),

        _buildDropdown("Frecuencia de fumar", "Fuma", ["Nunca", "Anteriormente", "Frecuentemente"]),
        const SizedBox(height: 24),
        _buildDropdown("Consumo de alcohol", "Alcohol", ["No consumo", "Bajo", "Moderado", "Alto"]),
        const SizedBox(height: 24),
        _buildDropdown("Actividad física", "Actividad", ["Bajo", "Moderado", "Alto"]),
        const SizedBox(height: 24),

        // Sueño: 0–24, máx 2 dígitos + opcional decimal
        _buildTextField(
          "Horas de sueño promedio", "Suenho", TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'^\d{0,2}(\.\d{0,1})?')),
          ],
          validator: (value) {
            if (value == null || value.isEmpty) return 'Campo obligatorio';
            final suenho = double.tryParse(value);
            if (suenho == null || suenho < 0 || suenho > 24) return 'Debe estar entre 0 y 24';
            return null;
          },
        ),
        const SizedBox(height: 24),

        _buildDropdown("Antecedentes familiares", "Antecedentes", ["Sí", "No"]),
        const SizedBox(height: 24),

        // Estrés: 1–9, solo 1 dígito
        _buildTextField(
          "Nivel de estrés (1-9)", "Estres", TextInputType.number,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(1),
          ],
          validator: (value) {
            if (value == null || value.isEmpty) return 'Campo obligatorio';
            final estres = int.tryParse(value);
            if (estres == null || estres < 1 || estres > 9) return 'Debe estar entre 1 y 9';
            return null;
          },
        ),
        const SizedBox(height: 24),

        _buildDropdown("Consumo de sal", "Sal", ["Bajo", "Moderado", "Alto"]),
      ],
    );
  }
}
