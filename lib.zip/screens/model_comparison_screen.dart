import 'package:flutter/material.dart';
import 'classification_metrics_tab.dart';
import 'auc_curves_tab.dart';

class ModelComparisonScreen extends StatefulWidget {
  const ModelComparisonScreen({super.key});

  @override
  State<ModelComparisonScreen> createState() => _ModelComparisonScreenState();
}

class _ModelComparisonScreenState extends State<ModelComparisonScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Comparación de Modelos"),
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,              // <- texto del tab seleccionado
          unselectedLabelColor: Colors.black87,  // <- texto del tab no seleccionado
          tabs: const [
            Tab(text: "Métricas de Clasificación"),
            Tab(text: "Curvas AUC"),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          ClassificationMetricsTab(),
          AucCurvesTab(),
        ],
      ),
    );
  }
}
