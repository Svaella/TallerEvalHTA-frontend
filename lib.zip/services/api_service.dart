// lib/services/api_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  //static const _baseUrl = 'http://192.168.1.38:8000';
  static const _baseUrl = 'https://tallerevalhta-913203481005.europe-west1.run.app';
  /// Predecir HTA enviando un JSON plano con "model" y todos tus campos.
  static Future<Map<String, dynamic>> predecirHTA(
    Map<String, dynamic> factors,
    String modelKey,
  ) async {
    final url = Uri.parse('$_baseUrl/predict');

    // A) Cambio clave "modelo" → "model"
    // B) Aplanar: todos los campos de factors al mismo nivel
    final body = {
      'model': modelKey,
      ...factors,
    };

    final resp = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(body),
    );

    if (resp.statusCode != 200) {
      throw Exception('Error ${resp.statusCode}: ${resp.body}');
    }
    return jsonDecode(resp.body) as Map<String, dynamic>;
  }
}
